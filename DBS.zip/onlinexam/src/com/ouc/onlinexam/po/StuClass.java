package com.ouc.onlinexam.po;

/**
 * 学生班级
 * @author Moons
 *
 */
public class StuClass {
	private int id;//班级编号
	private String name;//班级名称
	private String deptName;// 所属方向 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

}
