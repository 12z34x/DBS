package com.ouc.onlinexam.po;

/**
 * 课程
 * @author Moons
 *
 */
public class Course {
	private int id;//课程编号
	private String name;//课程名称
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
