package com.ouc.onlinexam.util;

public enum Department {
	计算机系,
	保密系
}
