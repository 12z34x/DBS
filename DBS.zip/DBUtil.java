﻿package com.hp.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class DBUtil {
	private static String Driver="com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql://localhost:3306/onlinexam";
	private static String user = "root";
	private static String pwd = "root";

	/**
	 * 静态初始化块 目的是类第一次被调用的时候 使用java来加载驱动类 前提下条件是，已经把jar包放到当前项目的构建路径
	 * 加载驱动类的方式是Class.forname com.mysql.jdbc.Driver是mysql的驱动类 com.mysql.jdbc是包名
	 */
// 静态初始化块，只在类加载的时候初始化一次，且只能初始化静态成员变量，不能初始化普通变量
	static {
		try {
			System.out.println("数据库连接");
			Class.forName(Driver);
//Class.forName("类名字符串")  （注：类名字符串是包名+类名）  说明：装入类,并做类的静态初始化，返回Class的对象
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public static Connection getConnection(){
		//定义一个变量，接收通过DriverManager获取的连接
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url,user,pwd);
//DriverManager在java.sql这个包里面,管理一组 JDBC 驱动程序的基本服务
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;

	}

	public static void main(String[] args) {
		/**
		 * 之前方法的调用使用对象名点方法
		 * 这个地方使用的类名点方法
		 * 区别在于，这个方法前面加了关键字static
		 * 如果一个方法加了static 关键字，则方法调用
		 * 使用类名点方法
		 */
		
		Connection c = DBUtil.getConnection();
		/**
		 * 如果获取了Connection对象，输出应该是
		 * com.mysql.Connection@****
		 * 如果获取失败，应该输出null或者错误
		 */
		System.out.println(c);
		String sql = "SELECT * FROM student";
		//创建一个集合框架List，里面存放的全是student对象
		List<Student> stuList = new ArrayList<Student>();
		try {
			/*
			 * 创建执行对象
			 */
			PreparedStatement pstmt = c.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
//jdbc直接写sql,然後返回ResultSet.get("字段名")就能得到数据库某条记录下该字段的值
				int id = rs.getInt("id");//此值为int型
				String name = rs.getString("name");//此值为string型
				System.out.println(id+"@@@"+name);
				Student s = new Student();
				s.setId(id);
				s.setStuname(name);
				//网框架里添加元素
				stuList.add(s);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i = 0 ;i<stuList.size();i++)
		{
			Student s = stuList.get(i);
			System.out.println(s.getId()+"###"+s.getStuname());
		}

	}
}
