/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50522
Source Host           : localhost:3306
Source Database       : onlinexam

Target Server Type    : MYSQL
Target Server Version : 50522
File Encoding         : 65001

Date: 2017-12-07 22:43:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('1', 'c++');
INSERT INTO `course` VALUES ('2', 'java');
INSERT INTO `course` VALUES ('3', 'python');
INSERT INTO `course` VALUES ('4', '数据库');
INSERT INTO `course` VALUES ('5', 'c语言');
INSERT INTO `course` VALUES ('8', 'mysql');
INSERT INTO `course` VALUES ('9', 'html5');

-- ----------------------------
-- Table structure for papers
-- ----------------------------
DROP TABLE IF EXISTS `papers`;
CREATE TABLE `papers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `testId` int(4) NOT NULL,
  `courseId` int(4) NOT NULL,
  `time` varchar(50) NOT NULL,
  `score` int(4) NOT NULL,
  `wrongQueId` varchar(255) NOT NULL,
  `wrongAns` varchar(255) NOT NULL,
  `studentId` int(4) NOT NULL,
  `createDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of papers
-- ----------------------------
INSERT INTO `papers` VALUES ('1', '1', '1', '50', '70', '1', 'A', '1', '2017-09-12 14:56:59');

-- ----------------------------
-- Table structure for questions
-- ----------------------------
DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `courseId` int(11) NOT NULL,
  `queType` int(11) NOT NULL,
  `queTitle` varchar(255) NOT NULL,
  `choiceA` varchar(255) NOT NULL,
  `choiceB` varchar(255) NOT NULL,
  `choiceC` varchar(255) NOT NULL,
  `choiceD` varchar(255) NOT NULL,
  `ans` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of questions
-- ----------------------------
INSERT INTO `questions` VALUES ('1', '1', '1', 'c++谁教的zui好', '海涛', '李华', '徐文华', '外星人', 'A');
INSERT INTO `questions` VALUES ('2', '2', '1', 'java难吗', '难如登天', '难', '中等', '简单', 'B');
INSERT INTO `questions` VALUES ('3', '3', '1', 'PYTHON好用不', '好用', '还行', '一般', '狗屎', 'A');
INSERT INTO `questions` VALUES ('4', '4', '1', '了解ssh么', '不了解', '还行', '听说过', '什么鬼', 'D');
INSERT INTO `questions` VALUES ('5', '1', '1', 'C++对C语言作了改进，（）使得C语言发生了质变，从面向过程变成了面向对象', '增加了一些新的运算符', '允许函数重载，并允许设置缺省参数', '规定函数说明必须用原型', '引进了类和对象的概念', 'D');
INSERT INTO `questions` VALUES ('6', '2', '1', 'java应用程序入口', 'init()', 'paint()', 'main()', 'start()', 'C');
INSERT INTO `questions` VALUES ('7', '1', '1', '关于new运算符，（　）是错误的', '它可以用来动态创建对象和对象数组', '使用它创建的对象或对象数组可以使用运算符delete删除', '使用它创建对象时要调用构造函数', '使用它创建对象数组时必须指定初始值', 'D');
INSERT INTO `questions` VALUES ('8', '1', '1', '数据封装就是将一组数据和与这组数据有关操作组装在一起，形成一个实体( )', '类', '对象', '函数体', '数据块', 'A');
INSERT INTO `questions` VALUES ('9', '2', '1', 'java所定义的版本中不包括', 'JAVA2EE', 'JAVA2CARD', 'JAVA2HE', 'JAVA2SE', 'C');
INSERT INTO `questions` VALUES ('10', '2', '1', '下列正确的是', 'JAVA程序main方法必须写在类里', 'JAVA程序中可以有多个main方法', 'JAVA程序中类名必须与文件名一样', 'JAVA程序main方法语句可以不用｛｝括起来', 'A');

-- ----------------------------
-- Table structure for stuclass
-- ----------------------------
DROP TABLE IF EXISTS `stuclass`;
CREATE TABLE `stuclass` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `deptName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of stuclass
-- ----------------------------
INSERT INTO `stuclass` VALUES ('1', '计算机一班', '计算机系');
INSERT INTO `stuclass` VALUES ('2', '计算机二班', '计算机系');
INSERT INTO `stuclass` VALUES ('3', '计算机三班', '计算机系');
INSERT INTO `stuclass` VALUES ('4', '保密一班', '计算机系');
INSERT INTO `stuclass` VALUES ('5', '保密二班', '计算机系');
INSERT INTO `stuclass` VALUES ('6', '开发一班', '软件工程');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `school` varchar(100) NOT NULL,
  `sex` varchar(11) NOT NULL,
  `born` varchar(50) NOT NULL,
  `classId` int(11) NOT NULL,
  `deptName` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '张伟', '123', '海大', '男', '1996-01-05', '1', '计算机系');
INSERT INTO `student` VALUES ('2', '王丽', '123', '海大', '女', '1997-11-13', '2', '计算机系');
INSERT INTO `student` VALUES ('3', '小明', '123', '海大', '男', '1997-9-11', '1', '计算机系');
INSERT INTO `student` VALUES ('4', '小红', '123', '海大', '女', '1996-11-16', '1', '计算机系');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `deptName` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('1', '小胖', '123', '计算机系');
INSERT INTO `teacher` VALUES ('2', '甜甜', '123', '计算机系');
INSERT INTO `teacher` VALUES ('5', '沈无邪', 'wuxie', '计算机系');
INSERT INTO `teacher` VALUES ('6', '李华', 'huahua', '计算机系');
INSERT INTO `teacher` VALUES ('7', '杨震', '123', '软件工程');

-- ----------------------------
-- Table structure for teachercourse
-- ----------------------------
DROP TABLE IF EXISTS `teachercourse`;
CREATE TABLE `teachercourse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teaId` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `classId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teachercourse
-- ----------------------------
INSERT INTO `teachercourse` VALUES ('1', '1', '1', '1');
INSERT INTO `teachercourse` VALUES ('2', '2', '2', '2');
INSERT INTO `teachercourse` VALUES ('3', '1', '1', '3');
INSERT INTO `teachercourse` VALUES ('4', '5', '4', '3');
INSERT INTO `teachercourse` VALUES ('5', '1', '2', '1');
INSERT INTO `teachercourse` VALUES ('7', '5', '9', '8');

-- ----------------------------
-- Table structure for test
-- ----------------------------
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `courseId` int(4) NOT NULL,
  `endDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `questions` varchar(255) NOT NULL,
  `teacherId` int(11) NOT NULL,
  `classIds` varchar(255) NOT NULL,
  `testTime` int(11) NOT NULL,
  `scores` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of test
-- ----------------------------
INSERT INTO `test` VALUES ('3', 'c++课程设计', '1', '2017-09-15 09:05:16', '5,1', '1', '1,3', '45', '100');
INSERT INTO `test` VALUES ('4', 'java小测', '2', '2017-09-16 09:43:59', '2', '1', '1,3', '45', '10');
INSERT INTO `test` VALUES ('5', 'c++小测2', '1', '2017-09-16 10:52:16', '5,1', '1', '1,3', '45', '10');
INSERT INTO `test` VALUES ('6', 'java小测验', '2', '2017-09-17 16:27:38', '2', '1', '1,3', '45', '100');
INSERT INTO `test` VALUES ('7', 'java小测验2', '2', '2017-09-15 16:29:54', '2', '1', '1,3', '45', '1');
INSERT INTO `test` VALUES ('8', 'java培训考试', '2', '2017-09-15 11:17:29', '2,6', '1', '1,3', '45', '10');
INSERT INTO `test` VALUES ('9', 'c++终极蛇皮考试', '1', '2017-09-20 20:02:26', '5,8,1,7', '1', '1,3', '45', '100');
INSERT INTO `test` VALUES ('10', 'java测试', '2', '2017-09-22 08:55:38', '6,2', '1', '1', '45', '10');
